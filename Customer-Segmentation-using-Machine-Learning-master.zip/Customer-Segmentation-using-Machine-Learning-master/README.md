# Customer-Segmentation-using-Machine-Learning

The retailer has hired us to help them create customer clusters, a.k.a "customer segments" through a data-driven approach.

They've provided us a dataset of past purchase data at the transaction level.
Our task is to build a clustering model using that dataset.
Our clustering model should factor in both aggregate sales patterns and specific items purchased.

This project is based on Unsupervised Learning.

Input dataset is present in Files folder.

I jupyter Notebbook their is actual coding right from Data Analysis to clustering using K-mean.
